# -*- coding: UTF-8 -*-

from commons import *

def initialize(data):
    data['output'] = ""
    data['input'] = ""

def main():
    data = {}
    initialize(data)

    return data['output']