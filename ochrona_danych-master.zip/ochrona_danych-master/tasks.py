
allowed_tasks = {
    'comment': '2 - zadania',
    2: {
        'comment': '1 - Kryptoanaliza\n2 - Popularne szyfry\'a, Playfair\n3 - RSA\n4 - Sumy kontrolne',
        1: {
            'comment': '1 - Kryptoanaliza tekstu \n2 - Szyfrowania tekstem podstawieniowym polialfabetycznym',
            1: 1, 2: 2},
        2: {
            'comment': '1 - Szyfr Cezara\n2 - Szyfr Vigenère\'a\n3 - Szyfr Playfair',
            1: 1, 2: 2, 3: 3},
        3: {
            'comment': '1 - Test Fermata\n2 - Wybór kluczy (RSA)\n3 - Szyfruj RSA',
            1: 1, 2: 2, 3: 3},
        4: {
            'comment': '1 - Pesel - kontrola\n2 - Algorytm Luhna\n3 - Suma CRC',
            1: 1, 2: 2, 3: 3},
    },
}
